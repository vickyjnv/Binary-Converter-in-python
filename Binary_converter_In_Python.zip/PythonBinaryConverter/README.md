# PythonBinaryConverter
Convert a decimal to the binary or convert a binary to the decimal. Writing in python is open source and published with GNU 3.0.
<br>
<H1>How to use?</H1>
1)Run 'BinCalculator.py'<br>
2)Select an operation for convertion<br>
And that is all.

